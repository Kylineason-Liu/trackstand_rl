#ifndef	__USART_H__
#define __USART_H__

#include "ti_msp_dl_config.h"
#include "stdio.h"
#include "imu_i2c_driver.h"
#include "imu_orientation.h"
#include "questions.h"

void USART_Init(void);

void USART_SendData(unsigned char data);

void USART_SendString(const char *str);
void print_task(void);


#endif
