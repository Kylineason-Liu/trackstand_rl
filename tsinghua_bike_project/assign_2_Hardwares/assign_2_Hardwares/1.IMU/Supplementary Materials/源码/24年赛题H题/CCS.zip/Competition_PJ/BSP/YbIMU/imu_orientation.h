#ifndef IMU_ORIENTATION_H
#define IMU_ORIENTATION_H

#include <stdint.h>

extern volatile float pitch, roll, yaw;
extern volatile float calibratedYaw, calibratedPitch, calibratedRoll;
extern float encoder_yaw;

void IMU_Orientation_Reset(float yaw_deg);
void IMU_YawEstimator_AddEncoderDelta(float delta_yaw_deg);
void Get_EulerAngles(void);
void Get_CalibratedAngles(void);

float Dir_PID(float error);
float navigetion_0_360_limit(float angle);
float get_minor_arc(float azimuth, float headingAngle);

#endif
