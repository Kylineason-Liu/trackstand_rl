################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/YbIMU/IOI2C.c \
../BSP/YbIMU/imu_i2c_driver.c \
../BSP/YbIMU/imu_orientation.c 

C_DEPS += \
./BSP/YbIMU/IOI2C.d \
./BSP/YbIMU/imu_i2c_driver.d \
./BSP/YbIMU/imu_orientation.d 

OBJS += \
./BSP/YbIMU/IOI2C.o \
./BSP/YbIMU/imu_i2c_driver.o \
./BSP/YbIMU/imu_orientation.o 

OBJS__QUOTED += \
"BSP\YbIMU\IOI2C.o" \
"BSP\YbIMU\imu_i2c_driver.o" \
"BSP\YbIMU\imu_orientation.o" 

C_DEPS__QUOTED += \
"BSP\YbIMU\IOI2C.d" \
"BSP\YbIMU\imu_i2c_driver.d" \
"BSP\YbIMU\imu_orientation.d" 

C_SRCS__QUOTED += \
"../BSP/YbIMU/IOI2C.c" \
"../BSP/YbIMU/imu_i2c_driver.c" \
"../BSP/YbIMU/imu_orientation.c" 


