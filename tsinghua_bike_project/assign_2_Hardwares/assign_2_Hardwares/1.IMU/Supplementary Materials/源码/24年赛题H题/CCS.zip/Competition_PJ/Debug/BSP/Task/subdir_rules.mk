################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
BSP/Task/%.o: ../BSP/Task/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: Arm Compiler'
	"E:/SoftWare/ti/CCS/ccs/tools/compiler/ti-cgt-armllvm_4.0.2.LTS/bin/tiarmclang.exe" -c @"syscfg/device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"C:/Users/leo/workspace_ccstheia/Competition_PJ" -I"C:/Users/leo/workspace_ccstheia/Competition_PJ/Debug" -I"E:/SoftWare/ti/mspm0_sdk_2_02_00_05/source/third_party/CMSIS/Core/Include" -I"E:/SoftWare/ti/mspm0_sdk_2_02_00_05/source" -I"C:/Users/leo/workspace_ccstheia/Competition_PJ/BSP/Eight_Tracking" -I"C:/Users/leo/workspace_ccstheia/Competition_PJ/BSP" -I"C:/Users/leo/workspace_ccstheia/Competition_PJ/BSP/YbIMU" -I"C:/Users/leo/workspace_ccstheia/Competition_PJ/BSP/Timer" -I"C:/Users/leo/workspace_ccstheia/Competition_PJ/BSP/Task" -I"C:/Users/leo/workspace_ccstheia/Competition_PJ/BSP/Questions" -I"C:/Users/leo/workspace_ccstheia/Competition_PJ/BSP/Motor" -I"C:/Users/leo/workspace_ccstheia/Competition_PJ/BSP/LED" -I"C:/Users/leo/workspace_ccstheia/Competition_PJ/BSP/Key" -I"C:/Users/leo/workspace_ccstheia/Competition_PJ/BSP/Buzzer" -gdwarf-3 -MMD -MP -MF"BSP/Task/$(basename $(<F)).d_raw" -MT"$(@)" -I"C:/Users/leo/workspace_ccstheia/Competition_PJ/Debug/syscfg"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


