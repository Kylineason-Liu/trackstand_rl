#include "app_motor.h"
#include "imu_orientation.h"

#define PI_F               3.1415926f
#define RAD2DEG_F          57.2957795f

static float speed_lr = 0;
static float speed_fb = 0;
static float speed_spin = 0;
static int speed_L1_setup = 0;
static int speed_L2_setup = 0;
static int speed_R1_setup = 0;
static int speed_R2_setup = 0;
static float g_encoder_mm_per_pulse = 1.0f;   // 每个脉冲对应的位移（毫米）  mm travelled per pulse

static void Motor_UpdateEncoderGeometry(float wheel_diameter_mm, uint16_t pulse_line, uint16_t pulse_phase)
{
    if (wheel_diameter_mm <= 0.0f || pulse_line == 0 || pulse_phase == 0) {
        return;    // 缺失参数则保持旧系数 keep previous scale if parameters unknown
    }
    float pulses_per_rev = (float)pulse_line * (float)pulse_phase;
    g_encoder_mm_per_pulse = (PI_F * wheel_diameter_mm) / pulses_per_rev;
}

// 返回当前小车轮距的一半   Returns half of the current small wheel axle spacing
static float Motion_Get_APB(void)
{
    return Car_APB;
}

void Set_Motor(int MOTOR_TYPE)
{
    if(MOTOR_TYPE == 1)
    {
        send_motor_type(1);//配置电机类型	Configure motor type
        delay_ms(100);
        send_pulse_phase(30);//配置减速比   Configure the reduction ratio
        delay_ms(100);
        send_pulse_line(11);//配置磁环线数   Configure the magnetic ring wire
        delay_ms(100);
        send_wheel_diameter(67.00);//配置轮径	Configure the wheel diameter
        delay_ms(100);
        send_motor_deadzone(1900);//配置电机死区	Configure the motor dead zone
        delay_ms(100);
        Motor_UpdateEncoderGeometry(67.0f, 11, 30);
    }
    
    else if(MOTOR_TYPE == 2)
    {
        send_motor_type(2);
        delay_ms(100);
        send_pulse_phase(20);
        delay_ms(100);
        send_pulse_line(13);
        delay_ms(100);
        send_wheel_diameter(48.00);
        delay_ms(100);
        send_motor_deadzone(1600);
        delay_ms(100);
        Motor_UpdateEncoderGeometry(48.0f, 13, 20);
    }
    
    else if(MOTOR_TYPE == 3)
    {
        send_motor_type(3);
        delay_ms(100);
        send_pulse_phase(45);
        delay_ms(100);
        send_pulse_line(13);
        delay_ms(100);
        send_wheel_diameter(68.00);
        delay_ms(100);
        send_motor_deadzone(1600);
        delay_ms(100);
        Motor_UpdateEncoderGeometry(68.0f, 13, 45);
    }
    
    else if(MOTOR_TYPE == 4)
    {
        send_motor_type(4);
        delay_ms(100);
        send_pulse_phase(48);
        delay_ms(100);
        send_motor_deadzone(1000);
        delay_ms(100);
    }
    
    else if(MOTOR_TYPE == 5)
    {
        send_motor_type(1);
        delay_ms(100);
        send_pulse_phase(40);
        delay_ms(100);
        send_pulse_line(11);
        delay_ms(100);
        send_wheel_diameter(67.00);
        delay_ms(100);
        send_motor_deadzone(1900);
        delay_ms(100);
        Motor_UpdateEncoderGeometry(67.0f, 11, 40);
    }
}

// 控制小车运动    Control the movement of the car
void Motion_Car_Control(int16_t V_x, int16_t V_y, int16_t V_z)
{
	float robot_APB = Motion_Get_APB();
	speed_lr = 0;
    speed_fb = V_x;
    speed_spin = (V_z / 1000.0f) * robot_APB;
    if (V_x == 0 && V_y == 0 && V_z == 0)
    {
        Contrl_Speed(0,0,0,0);
        return;
    }

    speed_L1_setup = speed_fb + speed_spin;
    speed_L2_setup = speed_fb + speed_spin;
    speed_R1_setup = speed_fb  - speed_spin;
    speed_R2_setup = speed_fb  - speed_spin;
		
    if (speed_L1_setup > 1000) speed_L1_setup = 1000;
    if (speed_L1_setup < -1000) speed_L1_setup = -1000;
    if (speed_L2_setup > 1000) speed_L2_setup = 1000;
    if (speed_L2_setup < -1000) speed_L2_setup = -1000;
    if (speed_R1_setup > 1000) speed_R1_setup = 1000;
    if (speed_R1_setup < -1000) speed_R1_setup = -1000;
    if (speed_R2_setup > 1000) speed_R2_setup = 1000;
    if (speed_R2_setup < -1000) speed_R2_setup = -1000;
    
    Contrl_Speed(speed_L1_setup, speed_L2_setup, speed_R1_setup, speed_R2_setup);
		
}

void Get_Odometry(void)
{
    Deal_data_real();

    float left_delta_pulses = (Encoder_Offset[0] + Encoder_Offset[1]) * 0.5f;
    float right_delta_pulses = (Encoder_Offset[2] + Encoder_Offset[3]) * 0.5f;
    float left_delta_mm = left_delta_pulses * g_encoder_mm_per_pulse;
    float right_delta_mm = right_delta_pulses * g_encoder_mm_per_pulse;
    float track_width_mm = Motion_Get_APB() * 2.0f;
    if(track_width_mm > 0.0f)
    {
        float delta_rad = (right_delta_mm - left_delta_mm) / track_width_mm;
        float delta_deg = delta_rad * RAD2DEG_F;
        //IMU_YawEstimator_AddEncoderDelta(delta_deg); // 使用编码器增量更新航向融合，默认关闭 Use encoder increments to update heading fusion, off by default
    }

    if(encoder_odometry_flag)
    {
        odometry_sum += ((Encoder_Offset[0] + Encoder_Offset[1] + Encoder_Offset[2] + Encoder_Offset[3]) / 4);
    }
}
