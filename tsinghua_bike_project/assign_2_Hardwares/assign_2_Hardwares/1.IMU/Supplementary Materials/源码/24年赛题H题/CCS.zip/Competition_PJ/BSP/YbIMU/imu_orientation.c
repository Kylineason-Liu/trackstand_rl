#include "imu_orientation.h"

#include "imu_i2c_driver.h"
#include "timer.h"

#define RAD2DEG (57.2957795f)
#define DEG2RAD (0.0174532925f)
#define COMPLEMENT_ALPHA (0.98f)

volatile float pitch = 0.0f;
volatile float roll = 0.0f;
volatile float yaw = 0.0f;

volatile float calibratedYaw = 0.0f;
volatile float calibratedPitch = 0.0f;
volatile float calibratedRoll = 0.0f;

static uint8_t orientation_initialized = 0;
static uint8_t encoder_initialized = 0;
static uint32_t last_gyro_tick = 0;
static float fused_yaw = 0.0f;
float encoder_yaw = 0.0f;
static float last_yaw_snapshot = 0.0f;

// 将角度折算为 [0,360) 区间 Wrap angle into [0,360)
static float wrap_360(float angle)
{
    while (angle >= 360.0f) {
        angle -= 360.0f;
    }
    while (angle < 0.0f) {
        angle += 360.0f;
    }
    return angle;
}

// 将角度折算为 (-180,180] 区间 Wrap angle into (-180,180]
static float wrap_pm180(float angle)
{
    while (angle > 180.0f) {
        angle -= 360.0f;
    }
    while (angle <= -180.0f) {
        angle += 360.0f;
    }
    return angle;
}

// 重置航向融合状态 Reset fused heading state
void IMU_Orientation_Reset(float yaw_deg)
{
    fused_yaw = wrap_360(yaw_deg);
    encoder_yaw = fused_yaw;
    yaw = fused_yaw;
    calibratedYaw = fused_yaw;

    last_yaw_snapshot = fused_yaw;
    orientation_initialized = 1;
    encoder_initialized = 0;
    last_gyro_tick = Get_Time();
}

// 注入编码器航向增量 Inject encoder heading delta
void IMU_YawEstimator_AddEncoderDelta(float delta_yaw_deg)
{
    if (!orientation_initialized) {
        IMU_Orientation_Reset(0.0f);
    }
    encoder_yaw = wrap_360(encoder_yaw + delta_yaw_deg);
    encoder_initialized = 1;
}

// 陀螺预测并结合编码器互补 Blend gyro prediction with encoder
static void update_yaw_from_gyro(float gyro_dps, float dt)
{
    float predicted = wrap_360(fused_yaw + gyro_dps * dt);
    if (encoder_initialized) //编码器互补默认关闭，可根据需要开启，但是需要重新调试 Complement with encoder, off by default, can be enabled if needed, but requires retuning
    {
        float encoder_ref = encoder_yaw;
        float error = wrap_pm180(encoder_ref - predicted);
        fused_yaw = wrap_360(predicted + (1.0f - COMPLEMENT_ALPHA) * error);
    } else {
        fused_yaw = predicted;
    }
    yaw = fused_yaw;
    // printf("p:%d ", (uint16_t)predicted);
}

// 读取姿态并驱动航向融合 Read posture and drive heading fusion
void Get_EulerAngles(void)
{
    // 获取欧拉角更新俯仰横滚 / Update pitch/roll from IMU Euler
    float euler[3];
    if (IMU_I2C_ReadEuler(euler) == 0) {
        pitch = euler[0];
        roll = euler[1];
        calibratedPitch = pitch;
        calibratedRoll = roll;
    }

    // 获取陀螺角速度 / Acquire gyro rates
    float gyro[3];
    if (IMU_I2C_ReadGyroscope(gyro) != 0) {
        return;
    }

    // 计算时间间隔 / Compute time delta since last call
    uint32_t now = Get_Time();
    if (!orientation_initialized) {
        IMU_Orientation_Reset(0.0f);
    }
    float dt = (now - last_gyro_tick) * 0.001f;
    if (dt <= 0.0f || dt > 0.5f) {
        dt = 0.005f;
    }
    last_gyro_tick = now;

    // 陀螺+编码器互补融合 / Fuse gyro with encoder reference
    float gyro_dps = gyro[2] * RAD2DEG;
    update_yaw_from_gyro(gyro_dps, dt);
}

// 生成连续航向角 Produce continuous heading angle
void Get_CalibratedAngles(void)
{
    // 计算 yaw 差并归一 / Normalize yaw difference
    float deltaYaw = wrap_pm180(yaw - last_yaw_snapshot);
    // 累加并限制范围 / Accumulate and wrap calibrated yaw
    calibratedYaw = wrap_360(calibratedYaw + deltaYaw);
    // 更新快照 / Update snapshot
    last_yaw_snapshot = yaw;
}

float dir_kp = 25.0f, dir_kd = 0.7f;
float last_error = 0.0f;

// 航向误差 PD 控制 Heading PD controller
float Dir_PID(float error)
{
    // 计算比例项 / Compute proportional term
    float result = dir_kp * error;
    // 叠加微分项 / Add derivative term based on error change
    result += dir_kd * (error - last_error);
    // 存储误差以备下次 / Store error for next call
    last_error = error;
    return result;
}

// 将角度限制到 0-360° Clamp angle to [0,360)
float navigetion_0_360_limit(float angle)
{
    return wrap_360(angle);
}

// 计算最短圆弧偏差 Compute minor-arc heading error
float get_minor_arc(float azimuth, float headingAngle)
{
    // 判断是否跨越 180° / Check wrap-around condition
    float angle_err = 0.0f;
    if(azimuth >= 180 + headingAngle)
    {
        angle_err = azimuth - headingAngle - 360;
    }
    else if(headingAngle > 180 + azimuth)
    {
        angle_err = azimuth - headingAngle + 360;
    }
    else
    {
        angle_err =  azimuth - headingAngle;
    }

    // 取负号以符合现有控制定义 / Return signed minor arc
    return -angle_err;
}
